var mongojs=require('mongojs');
var db=mongojs('pro',['rest']);
db.rest.aggregate([{$match:{country:"US-zone-3"}},{$sort:{city:-1}}],function(err,res){
  console.log(JSON.stringify(res));
});