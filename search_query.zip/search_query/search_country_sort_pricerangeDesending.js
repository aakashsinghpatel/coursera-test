var mongojs=require('mongojs');
var db=mongojs('pro',['rest']);


db.rest.aggregate([{$match:{country:"US-zone-1"}},{$sort:{priceRange:-1}}],{allowDiskUse: true},function(err,res){
  console.log(JSON.stringify(res));
});