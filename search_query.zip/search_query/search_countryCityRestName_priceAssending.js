
var mongojs=require('mongojs');
var db=mongojs('pro',['rest']);
db.rest.aggregate([{$match:{country:"US-zone-1",city:"Oxford",name:"Corner Grill Drinkery"}},{$sort:{priceRange:1}}],{allowDiskUse: true},function(err,res){
  console.log(JSON.stringify(res));
});